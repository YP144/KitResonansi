/*
 *  TFFlashBuffer - Ring buffer in EEPROM/Flash Memory
 *
 * (c) Eko M. Budi, 2022
 * Released into the public domain.
 */


#ifndef TFFlashBuffer_h
#define TFFlashBuffer_h

#include <Arduino.h>
#include <EEPROM.h>

template <typename TYPE>
class FlashData
{
  protected:
    uint16_t mark;
    unsigned addr_mark, addr_data;

  public:
    FlashData(unsigned addr=0, uint16_t id_mark=sizeof(TYPE)) {
      mark = id_mark;
      addr_mark = addr;
      addr_data = addr_mark + sizeof(uint16_t);
    }

    unsigned memSize() {
      return sizeof(TYPE)+sizeof(byte);
    }

    void save(TYPE &data) {      
      EEPROM.put(addr_mark, mark);
      EEPROM.put(addr_data, data);
      EEPROM.commit();
    }

    boolean load(TYPE &data) {
      uint16_t m;
      EEPROM.get(addr_mark, m);
      if (m != mark) return false;
      EEPROM.get(addr_data, data);
      return true;
    }

    void erase() {
      uint16_t m=0;
      EEPROM.put(addr_mark, m);
      EEPROM.commit();
    }
};


template <int16_t NROW, typename TYPE=int>
class FlashBuffer
{
  protected:
    int16_t head, tail;
    uint32_t number; 
    int16_t cnt;
    int16_t mark;
    int16_t addr_mark, addr_head,
      addr_tail, addr_num, addr_buff;

    void write(unsigned idx, TYPE &a) {
      byte* d = (byte*) &a;
      unsigned addr=addr_buff + (idx * sizeof(TYPE));
      for(int i=sizeof(TYPE); i--;) {
        EEPROM.write(addr++, *d++);
      }
    }

    void read(unsigned idx, TYPE &a) {
      byte* d = (byte*) &a;
      unsigned addr=addr_buff + (idx * sizeof(TYPE));
      for(int i=sizeof(TYPE); i--;) {
        *d++ = EEPROM.read(addr++);
      }
    }

    void zeros(TYPE &a) {
      memset(&a, 0, sizeof(TYPE));
    }

  public:
    FlashBuffer(unsigned addr=0, int16_t id_mark=NROW*sizeof(TYPE)) {
      cnt = 0;   // still unloaded
      mark = id_mark;
      setAddr(addr);
    }
    
    void setAddr(unsigned addr) {
      addr_mark = addr;
      addr_head = addr_mark + sizeof(int16_t);
      addr_tail = addr_head + sizeof(int16_t);
      addr_num = addr_tail + sizeof(int16_t);
      addr_buff = addr_num + sizeof(int32_t);      
    }

    unsigned memSize() {
      return (NROW*sizeof(TYPE))+(3*sizeof(int16_t))+sizeof(int32_t);
    }

    void init() {
      number = 0;
      EEPROM.put(addr_mark, mark);
      EEPROM.put(addr_num, number);
      reset();
    }

    void erase() {
      int16_t d=0;
      EEPROM.put(addr_mark, d);
      EEPROM.commit();
    }

    boolean load() {
      int16_t r;
      EEPROM.get(addr_mark, r);
      if ((r != mark)) {
        return false; 
      }
      EEPROM.get(addr_head, head);
      EEPROM.get(addr_tail, tail);
      EEPROM.get(addr_num, number);
      if (tail == -1) cnt = 0;
      else if (tail <= head) cnt = (head-tail+1);
      else cnt = head + NROW - tail + 1;
      return true;
    }

    unsigned row() {return NROW;}
    unsigned lastNumber() {return number;}
    
    unsigned count() {return cnt;}
    bool isFull() {return cnt == NROW;}
    bool isEmpty() {return cnt == 0;}
    
    void reset() {
      cnt = head = 0;
      tail = -1;
      EEPROM.put(addr_head, head);
      EEPROM.put(addr_tail, tail);
      EEPROM.commit();
    }

    /* Put an item in the head of buffer
     * return count
     */
    void put(TYPE &rdata) {
      if (isEmpty()) {
        write(head, rdata);
        tail=head;
        EEPROM.put(addr_tail, tail);
        cnt = 1;
      }
      else {
        if (isFull()) {
          tail = (tail+1) % NROW;
          EEPROM.put(addr_tail, tail);
        }
        else {
          cnt++;      
        }
        head = (head+1) % NROW;
        write(head, rdata);
        EEPROM.put(addr_head, head);
      }
      number++;
      EEPROM.put(addr_num, number);
      EEPROM.commit();      
    }
    
    /* Take the last (recently put) item of buffer (LIFO)
     * return false if buffer is empty
     */
    bool pop(TYPE &rdata) {
      if (isEmpty()) {
        zeros(rdata);
        return false;
      }
      read(head, rdata);
      if (cnt == 1) {
        reset();
      }
      else {
        head = (head ? head-1: NROW-1);
        cnt--;
        EEPROM.put(addr_head, head);
        EEPROM.commit();
      }
      return true;  
    }
      
    /* Take the first item from buffer (FIFO)
     * return false if buffer is empty
     */
    bool take(TYPE &rdata) {
      if (isEmpty()) {
        zeros(rdata);
        return false;
      }
      read(tail,  rdata);
      if (cnt == 1) {
        reset();
      }
      else {
        tail = (tail+1) % NROW;
        cnt--;
        EEPROM.put(addr_tail, tail);
        EEPROM.commit();
      }
      return true;  
    }

    // just synonim ...
    bool takeLast(TYPE &rdata) {return pop(rdata);}
    bool takeFirst(TYPE &rdata) {return take(rdata);}

    bool getFirst(TYPE &rdata) {
      if (cnt <= 0) {
        zeros(rdata);
        return false;
      }
      read(tail, rdata);
      return true;  
    }

    bool getFirst(unsigned r, TYPE &rdata) {
      if (r > cnt-1) {
        zeros(rdata);
        return false;
      }
      int idx = (r+tail) % NROW;
      read(idx, rdata);
      return true;  
    }

    bool getLast(TYPE &rdata) {
      if (cnt <= 0) {
        zeros(rdata);
        return false;
      }
      read(head, rdata);
      return true;  
    }
      
    bool getLast(unsigned r, TYPE &rdata) {
      if (r > cnt-1) {
        zeros(rdata);
        return false;
      }
      int idx = head-r;
      if (idx < 0) idx += NROW; 
      read(idx, rdata);
      return true;  
    }
};


#endif
